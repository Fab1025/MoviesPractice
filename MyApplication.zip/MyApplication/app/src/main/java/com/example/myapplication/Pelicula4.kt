package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton

class Pelicula4 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pelicula4)
        val btnInicio: ImageButton = findViewById(R.id.btnInicio)
        val btnIntenttoActivitytwo: Button = findViewById(R.id.btnIntenttoActivitytwo)
        val btnSiguiente: Button = findViewById(R.id.btnSiguiente)

        btnInicio.setOnClickListener(){
            startActivity(Intent(this,MainActivity::class.java))

        }
        btnSiguiente.setOnClickListener(){
            startActivity(Intent(this,Pelicula5::class.java))

        }

        btnIntenttoActivitytwo.setOnClickListener(){
            startActivity(Intent(this,Pelicula6::class.java))

        }

    }

}