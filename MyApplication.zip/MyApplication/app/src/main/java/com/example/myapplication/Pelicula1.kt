package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import com.example.myapplication.R.layout.activity_pelicula1
import org.imaginativeworld.whynotimagecarousel.ImageCarousel

class Pelicula1 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(activity_pelicula1)

        val btnIntenttoActivitytwo: Button = findViewById(R.id.btnIntenttoActivitytwo)
        val btnSiguiente: Button = findViewById(R.id.btnSiguiente)
        val btnInicio: ImageButton = findViewById(R.id.btnInicio)
        btnIntenttoActivitytwo.setOnClickListener(){
        startActivity(Intent(this,Pelicula2::class.java))

        }
        btnSiguiente.setOnClickListener(){
            startActivity(Intent(this,Pelicula3::class.java))


        }
        btnInicio.setOnClickListener(){
            startActivity(Intent(this,MainActivity::class.java))

        }

    }
}